sp_helpconstraint Materiales


INSERT INTO Materiales values(1000,'xxx', 1000)

ALTER TABLE Entregan add constraint llaveMateriales Primary KEY (Clave)

INSERT INTO Materiales values(1000,'xxx', 1000)

ALTER TABLE Proveedores add constraint llaveProveedores Primary KEY (RFC)
ALTER TABLE Proyectos add constraint llaveProyectos Primary KEY (Numero)

ALTER TABLE Entregan add constraint llaveEntregan Primary KEY (Clave, RFC, Numero, Fecha)

Select *
From Entregan


