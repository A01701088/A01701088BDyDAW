IF EXISTS(SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'Materiales')

DROP TABLE Materiales

CREATE TABLE Materiales
(
	Clave numeric(5) not null,
	Descripcion varchar(50),
	Costo numeric (8,2)
)

IF EXISTS(SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'Proveedores')

DROP TABLE Proveedores

CREATE Table Proveedores
(
	RFC Char(13) not null,
	RazonSocial VARCHAR(50)

)

IF EXISTS(SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'Proyectos')

DROP TABLE Proyectos

CREATE Table Proyectos
(
	Numero NUMERIC(5) not null,
	Denominacion VARCHAR(50)


)

IF EXISTS(SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'Entregan')

DROP TABLE Entregan

CREATE Table Entregan
(
	Clave numeric(5) not null,
	RFC Char(13) not null,
	Numero NUMERIC(5) not null,
	Fecha DATETIME not null,
	Cantidad NUMERIC(8,2)


)

BULK INSERT a1701088.a1701088.[Proyectos]
FROM 'e:\wwwroot\rcortese\proyectos.csv'
WITH 
(
	CODEPAGE = 'ACP',
	FIELDTERMINATOR = ',',
	ROWTERMINATOR = '\n'
)

SELECT * 
FROM Proyectos


BULK INSERT a1701088.a1701088.[Materiales]
FROM 'e:\wwwroot\rcortese\materiales.csv'
WITH 
(
	CODEPAGE = 'ACP',
	FIELDTERMINATOR = ',',
	ROWTERMINATOR = '\n'
)

SELECT * 
FROM Materiales

BULK INSERT a1701088.a1701088.[Proveedores]
FROM 'e:\wwwroot\rcortese\proveedores.csv'
WITH 
(
	CODEPAGE = 'ACP',
	FIELDTERMINATOR = ',',
	ROWTERMINATOR = '\n'
)

SELECT * 
FROM Proveedores

SET DATEFORMAT dmy

BULK INSERT a1701088.a1701088.[Entregan]
FROM 'e:\wwwroot\rcortese\entregan.csv'
WITH 
(
	CODEPAGE = 'ACP',
	FIELDTERMINATOR = ',',
	ROWTERMINATOR = '\n'
)

SELECT * 
FROM Entregan

