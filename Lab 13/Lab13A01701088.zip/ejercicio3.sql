sp_helpconstraint Entregan

Select *
From Proyectos

Select *
From Proveedores

Select *
From Materiales





DELETE FROM Entregan where Clave=0

ALTER TABLE entregan add constraint cfentreganclave FOREIGN KEY (Clave) REFERENCES Materiales(Clave)

INSERT INTO entregan values (0, 'xxx', 0, '1-jan-02', 0)

ALTER TABLE entregan add constraint cfentreganrfc FOREIGN KEY (RFC) REFERENCES Proveedores(RFC)

ALTER TABLE entregan add constraint cfentregannumero FOREIGN KEY (Numero) REFERENCES Proyectos(Numero)


Select *
From Entregan