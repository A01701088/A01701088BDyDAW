
DELETE From Entregan WHERE Cantidad=0

ALTER TABLE Entregan add constraint Cantidad check (Cantidad > 0)

INSERT INTO Entregan values(1000, 'AAAA800101', 5000, GETDATE(), 0)

SELECT *
FROM Entregan