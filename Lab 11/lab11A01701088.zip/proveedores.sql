BULK INSERT a1701088.a1701088.[Proveedores]
FROM 'e:\wwwroot\rcortese\proveedores.csv'
WITH 
(
	CODEPAGE = 'ACP',
	FIELDTERMINATOR = ',',
	ROWTERMINATOR = '\n'
)

SELECT * 
FROM Proveedores