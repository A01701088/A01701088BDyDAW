SET DATEFORMAT dmy

BULK INSERT a1701088.a1701088.[Entregan]
FROM 'e:\wwwroot\rcortese\entregan.csv'
WITH 
(
	CODEPAGE = 'ACP',
	FIELDTERMINATOR = ',',
	ROWTERMINATOR = '\n'
)

SELECT * 
FROM Entregan