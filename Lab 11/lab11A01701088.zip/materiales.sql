BULK INSERT a1701088.a1701088.[Materiales]
FROM 'e:\wwwroot\rcortese\materiales.csv'
WITH 
(
	CODEPAGE = 'ACP',
	FIELDTERMINATOR = ',',
	ROWTERMINATOR = '\n'
)

SELECT * 
FROM Materiales